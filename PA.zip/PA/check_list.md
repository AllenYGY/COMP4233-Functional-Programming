
Name: 杨钧涯
ID: 2230026188

- [x] Parsing `if`
- [x] Evaluating `if`
- [x] Parsing function and function application
- [x] Evaluating function and function application
- [x] Parsing & Evaluating `<=`
- [x] Parsing & Evaluating `^`
- [x] Parsing lists
- [x] Evaluating lists
