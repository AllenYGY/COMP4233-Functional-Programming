
Name:  
ID:  

- [ ] Parsing `if`
- [ ] Evaluating `if`
- [ ] Parsing function and function application
- [ ] Evaluating function and function application
- [ ] Parsing & Evaluating `<=`
- [ ] Parsing & Evaluating `^`
- [ ] Parsing lists
- [ ] Evaluating lists
